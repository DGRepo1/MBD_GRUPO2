const express = require('express');
const router = express.Router();
const { listarClientes } = require('../controllers/cliente.controller');

router.get('/', listarClientes);

module.exports = router;

// backend/routes/cliente.routes.js