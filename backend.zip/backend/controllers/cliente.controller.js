const connection = require('../database');

async function listarClientes(req, res) {
  try {
    const result = await connection.execute(
      `SELECT IdCliente AS idCliente, NombreCliente AS nombre, CorreoCliente AS correo FROM Cliente`
    );
    const clientes = result.rows.map(row => ({
      idCliente: row[0],
      nombre: row[1],
      correo: row[2]
    }));
    res.json(clientes);
  } catch (error) {
    console.error("Error al obtener clientes:", error);
    res.status(500).json({ error: 'Error al obtener clientes' });
  }
}

module.exports = {
  listarClientes
};

// backend/controllers/cliente.controller.js