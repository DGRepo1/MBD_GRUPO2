// src/pages/DashboardAdmin.jsx
import { useEffect, useState } from 'react';
import { obtenerCasos, obtenerAbogados } from '../services/api';
import TablaCasos from '../components/TablaCasos';

export default function DashboardAdmin() {
  const [casos, setCasos] = useState([]);
  const [abogados, setAbogados] = useState([]);
  const [asignaciones, setAsignaciones] = useState([]);

  useEffect(() => {
    async function fetchData() {
      try {
        const datosCasos = await obtenerCasos();
        const datosAbogados = await obtenerAbogados();

        const resAsignaciones = await fetch('http://localhost:3000/api/asignaciones');
        if (!resAsignaciones.ok) {
          throw new Error(`HTTP error ${resAsignaciones.status}`);
        }
        const datosAsignaciones = await resAsignaciones.json();


        console.log("📌 Asignaciones:", datosAsignaciones);

        setCasos(datosCasos);
        setAbogados(datosAbogados);
        setAsignaciones(datosAsignaciones);
      } catch (error) {
        console.error('❌ Error al cargar datos:', error);
      }
    }

    fetchData();
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-blue-800 mb-4">Panel Administrador</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-blue-100 p-4 rounded">Total casos: {casos.length}</div>
        <div className="bg-yellow-100 p-4 rounded">Casos sin asignar: {casos.filter(c => !c.asignado).length}</div>
        <div className="bg-green-100 p-4 rounded">Total abogados: {abogados.length}</div>
      </div>

      <TablaCasos casos={casos} abogados={abogados} />

      <h2 className="text-xl font-semibold mt-10 mb-2 text-blue-700">Asignaciones recientes</h2>
      <table className="w-full border text-sm">
        <thead className="bg-gray-100">
          <tr>
            <th>ID</th>
            <th>Fecha</th>
            <th>Cliente</th>
            <th>Caso</th>
            <th>Especialidad</th>
            <th>Abogado</th>
          </tr>
        </thead>
        <tbody>
          {asignaciones.map((a, i) => (
            <tr key={i} className="border-t">
              <td>{a.idAsignacion}</td>
              <td>{new Date(a.fecha).toLocaleDateString()}</td>
              <td>{a.cliente}</td>
              <td>{a.caso}</td>
              <td>{a.especialidad}</td>
              <td>{a.abogado}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

