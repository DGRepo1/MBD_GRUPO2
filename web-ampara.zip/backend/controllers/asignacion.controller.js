const { connect } = require('../db/connection');
const oracledb = require('oracledb');


async function asignarCaso(req, res) {
  const { idCasoLegal, idAbogado } = req.body;

  try {
    const conn = await connect();
    await conn.execute(
      `BEGIN SP_ASIGNAR_CASO(:caso, :abogado); END;`,
      {
        caso: parseInt(idCasoLegal),
        abogado: parseInt(idAbogado)
      }
    );
    await conn.close();
    res.json({ mensaje: 'Caso asignado correctamente' });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
}

async function listarAsignaciones(req, res) {
  try {
    const conn = await connect();
    const result = await conn.execute(
      `BEGIN :cursor := SP_LISTAR_ASIGNACIONES(); END;`,
      {
        cursor: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
      }
    );

    const cursor = result.outBinds.cursor;
    const rows = await cursor.getRows();
    await cursor.close();
    await conn.close();

    const asignaciones = rows.map(r => ({
      idAsignacion: r[0],
      fecha: r[1],
      cliente: r[2],
      caso: r[3],
      especialidad: r[4],
      abogado: r[5]
    }));

    res.json(asignaciones);

  } catch (error) {
    console.error("❌ Error en listarAsignaciones:", error);
    res.status(500).json({ message: 'Error al listar asignaciones' });
  }
}



async function eliminarAsignacion(req, res) {
  const { id } = req.params;
  try {
    const conn = await connect();
    await conn.execute(
      `BEGIN SP_ELIMINAR_ASIGNACION(:idAsignacion); END;`,
      { idAsignacion: parseInt(id) }
    );
    await conn.close();
    res.json({ mensaje: 'Asignación eliminada' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al eliminar asignación' });
  }
}

module.exports = {
  asignarCaso,
  listarAsignaciones,
  eliminarAsignacion
};
